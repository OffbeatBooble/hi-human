package com.nnpg.glazed.modules.pvp;

import com.nnpg.glazed.GlazedAddon;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;

import java.util.Random;

public class ReactiveShieldBreaker extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final Random random = new Random();
    private long lastActionTime = 0;

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> useBestAxe = sgGeneral.add(new BoolSetting.Builder()
        .name("use-best-axe")
        .description("Select the strongest axe available instead of the first one found.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> minDelay = sgGeneral.add(new IntSetting.Builder()
        .name("min-delay-ms")
        .description("Minimum delay between shield break attempts in milliseconds.")
        .defaultValue(100)
        .min(0)
        .sliderMax(500)
        .build()
    );

    private final Setting<Integer> maxDelay = sgGeneral.add(new IntSetting.Builder()
        .name("max-delay-ms")
        .description("Maximum delay between shield break attempts in milliseconds.")
        .defaultValue(150)
        .min(0)
        .sliderMax(1000)
        .build()
    );

    public ReactiveShieldBreaker() {
        super(GlazedAddon.pvp, "reactive-shield-breaker", "Switch to axe and hit if target blocks with a shield.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof EntityHitResult entityHit)) return;

        Entity targetEntity = entityHit.getEntity();
        if (!(targetEntity instanceof PlayerEntity target)) return;

        // Check if target has shield in either hand
        ItemStack mainHand = target.getMainHandStack();
        ItemStack offHand = target.getOffHandStack();
        if (!mainHand.isOf(Items.SHIELD) && !offHand.isOf(Items.SHIELD)) return;

        // Random human-like delay
        int min = minDelay.get();
        int max = Math.max(min, maxDelay.get());
        int delay = min + random.nextInt(max - min + 1);

        long now = System.currentTimeMillis();
        if (now - lastActionTime < delay) return;

        // Find axe slot
        int axeSlot = useBestAxe.get() ? findBestAxeSlot() : findFirstAxeSlot();
        if (axeSlot == -1) return;

        // Swap to axe and attack
        InvUtils.swap(axeSlot, true);
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        InvUtils.swapBack(); // restore previous slot

        lastActionTime = now;
    }

    private int findFirstAxeSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (isAxe(stack)) return i;
        }
        return -1;
    }

    private int findBestAxeSlot() {
        int bestSlot = -1;
        int bestPriority = -1;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            int priority = getAxePriority(stack);
            if (priority > bestPriority) {
                bestPriority = priority;
                bestSlot = i;
            }
        }
        return bestSlot;
    }

    private boolean isAxe(ItemStack stack) {
        return stack.isOf(Items.WOODEN_AXE) || stack.isOf(Items.STONE_AXE) ||
            stack.isOf(Items.IRON_AXE) || stack.isOf(Items.GOLDEN_AXE) ||
            stack.isOf(Items.DIAMOND_AXE) || stack.isOf(Items.NETHERITE_AXE);
    }

    private int getAxePriority(ItemStack stack) {
        if (stack.isOf(Items.NETHERITE_AXE)) return 6;
        if (stack.isOf(Items.DIAMOND_AXE)) return 5;
        if (stack.isOf(Items.IRON_AXE)) return 4;
        if (stack.isOf(Items.STONE_AXE)) return 3;
        if (stack.isOf(Items.WOODEN_AXE)) return 2;
        if (stack.isOf(Items.GOLDEN_AXE)) return 1;
        return -1;
    }
}
