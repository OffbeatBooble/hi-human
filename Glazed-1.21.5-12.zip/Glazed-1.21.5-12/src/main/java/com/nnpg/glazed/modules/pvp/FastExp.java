package com.nnpg.glazed.modules.pvp;

import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

import java.util.concurrent.ThreadLocalRandom;

import com.nnpg.glazed.GlazedAddon;
import com.nnpg.glazed.VersionUtil;

public class FastExp extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> active = sgGeneral.add(new BoolSetting.Builder()
        .name("active")
        .description("Whether the module is active")
        .defaultValue(true)
        .build()
    );

    private final Setting<Double> useDelay = sgGeneral.add(new DoubleSetting.Builder()
        .name("use-delay-ms")
        .description("Randomized delay between throwing XP bottles")
        .defaultValue(100)
        .min(50)
        .max(500)
        .sliderMax(500)
        .build()
    );

    private long lastUseTime;

    public FastExp() {
        super(GlazedAddon.pvp, "fast-xp", "Automatically throws XP bottles in a legit, human-like way.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!active.get() || mc.player == null || mc.world == null) return;

        // Check delay
        if (System.currentTimeMillis() - lastUseTime < getRandomDelay()) return;

        // Find XP bottle in hotbar
        int xpSlot = findXPInHotbar();
        if (xpSlot == -1) return;

        // Switch to XP slot using VersionUtil
        if (VersionUtil.getSelectedSlot(mc.player) != xpSlot) {
            VersionUtil.setSelectedSlot(mc.player, xpSlot);
        }

        // Right-click XP bottle (main hand)
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);

        lastUseTime = System.currentTimeMillis();
    }

    private int findXPInHotbar() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isOf(Items.EXPERIENCE_BOTTLE)) return i;
        }
        return -1;
    }

    private long getRandomDelay() {
        double base = useDelay.get();
        return (long) (base + ThreadLocalRandom.current().nextDouble(-base * 0.2, base * 0.2));
    }
}
