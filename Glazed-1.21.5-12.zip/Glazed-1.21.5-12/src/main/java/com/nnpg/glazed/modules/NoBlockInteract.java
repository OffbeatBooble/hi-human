package com.nnpg.glazed.modules;

import com.nnpg.glazed.GlazedAddon;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.meteorclient.events.world.TickEvent;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Hand;

import java.util.Set;

public class NoBlockInteract extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public NoBlockInteract() {
        super(GlazedAddon.CATEGORY, "no-block-interact", "Prevents interacting with containers, signs, shulkers, and ender chests.");
    }

    private final Set<Block> blockedBlocks = Set.of(
        // Containers / utility blocks
        Blocks.CHEST,
        Blocks.ENDER_CHEST,
        Blocks.TRAPPED_CHEST,
        Blocks.CRAFTING_TABLE,
        Blocks.ENCHANTING_TABLE,
        Blocks.ANVIL,
        Blocks.LECTERN,
        Blocks.BARREL,
        Blocks.SMITHING_TABLE,
        Blocks.FURNACE,
        Blocks.BLAST_FURNACE,
        Blocks.SMOKER,

        // Signs (standing + wall, all wood types)
        Blocks.OAK_SIGN, Blocks.OAK_WALL_SIGN,
        Blocks.SPRUCE_SIGN, Blocks.SPRUCE_WALL_SIGN,
        Blocks.BIRCH_SIGN, Blocks.BIRCH_WALL_SIGN,
        Blocks.JUNGLE_SIGN, Blocks.JUNGLE_WALL_SIGN,
        Blocks.ACACIA_SIGN, Blocks.ACACIA_WALL_SIGN,
        Blocks.DARK_OAK_SIGN, Blocks.DARK_OAK_WALL_SIGN,
        Blocks.CRIMSON_SIGN, Blocks.CRIMSON_WALL_SIGN,
        Blocks.WARPED_SIGN, Blocks.WARPED_WALL_SIGN,
        Blocks.MANGROVE_SIGN, Blocks.MANGROVE_WALL_SIGN,
        Blocks.BAMBOO_SIGN, Blocks.BAMBOO_WALL_SIGN,
        Blocks.CHERRY_SIGN, Blocks.CHERRY_WALL_SIGN,

        // Hanging Signs (standing + wall, all wood types)
        Blocks.OAK_HANGING_SIGN, Blocks.OAK_WALL_HANGING_SIGN,
        Blocks.SPRUCE_HANGING_SIGN, Blocks.SPRUCE_WALL_HANGING_SIGN,
        Blocks.BIRCH_HANGING_SIGN, Blocks.BIRCH_WALL_HANGING_SIGN,
        Blocks.JUNGLE_HANGING_SIGN, Blocks.JUNGLE_WALL_HANGING_SIGN,
        Blocks.ACACIA_HANGING_SIGN, Blocks.ACACIA_WALL_HANGING_SIGN,
        Blocks.DARK_OAK_HANGING_SIGN, Blocks.DARK_OAK_WALL_HANGING_SIGN,
        Blocks.CRIMSON_HANGING_SIGN, Blocks.CRIMSON_WALL_HANGING_SIGN,
        Blocks.WARPED_HANGING_SIGN, Blocks.WARPED_WALL_HANGING_SIGN,
        Blocks.MANGROVE_HANGING_SIGN, Blocks.MANGROVE_WALL_HANGING_SIGN,
        Blocks.BAMBOO_HANGING_SIGN, Blocks.BAMBOO_WALL_HANGING_SIGN,
        Blocks.CHERRY_HANGING_SIGN, Blocks.CHERRY_WALL_HANGING_SIGN,

        // Shulker Boxes (all colors)
        Blocks.SHULKER_BOX,
        Blocks.WHITE_SHULKER_BOX,
        Blocks.ORANGE_SHULKER_BOX,
        Blocks.MAGENTA_SHULKER_BOX,
        Blocks.LIGHT_BLUE_SHULKER_BOX,
        Blocks.YELLOW_SHULKER_BOX,
        Blocks.LIME_SHULKER_BOX,
        Blocks.PINK_SHULKER_BOX,
        Blocks.GRAY_SHULKER_BOX,
        Blocks.LIGHT_GRAY_SHULKER_BOX,
        Blocks.CYAN_SHULKER_BOX,
        Blocks.PURPLE_SHULKER_BOX,
        Blocks.BLUE_SHULKER_BOX,
        Blocks.BROWN_SHULKER_BOX,
        Blocks.GREEN_SHULKER_BOX,
        Blocks.RED_SHULKER_BOX,
        Blocks.BLACK_SHULKER_BOX
    );

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.crosshairTarget == null) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hitResult)) return;

        BlockPos pos = hitResult.getBlockPos();
        Block block = mc.world.getBlockState(pos).getBlock();

        if (blockedBlocks.contains(block) && mc.options.useKey.isPressed()) {
            // Prevent interaction by sending only a swing packet
            mc.player.swingHand(Hand.MAIN_HAND);

            // Suppress further interaction
            mc.options.useKey.setPressed(false);
        }
    }
}




