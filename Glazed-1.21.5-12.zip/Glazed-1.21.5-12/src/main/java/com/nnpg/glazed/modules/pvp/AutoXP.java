package com.nnpg.glazed.modules.pvp;

import com.nnpg.glazed.GlazedAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

public class AutoXP extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> preferredSlot = sgGeneral.add(new IntSetting.Builder()
        .name("preferred-hotbar-slot")
        .description("Which hotbar slot to move XP bottles to (0 = leftmost, 8 = rightmost)")
        .defaultValue(7)
        .min(0)
        .max(8)
        .sliderMax(8)
        .build()
    );

    private final Setting<Boolean> alertOnMove = sgGeneral.add(new BoolSetting.Builder()
        .name("alert-on-move")
        .description("Send a chat message when XP bottles are moved to hotbar")
        .defaultValue(true)
        .build()
    );

    private int tickDelay = 0;

    public AutoXP() {
        super(GlazedAddon.pvp, "auto-xp", "Moves XP bottles from inventory to a preferred hotbar slot.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;
        if (tickDelay > 0) {
            tickDelay--;
            return;
        }

        int xpSlot = findXPBottleSlot();
        int targetSlot = preferredSlot.get();

        if (xpSlot != -1 && isHotbarSlotEmpty(targetSlot)) {
            int screenXP = xpSlot < 9 ? 36 + xpSlot : xpSlot;
            int screenTarget = 36 + targetSlot;

            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, screenXP, 0, SlotActionType.PICKUP, mc.player);
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, screenTarget, 0, SlotActionType.PICKUP, mc.player);
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, screenXP, 0, SlotActionType.PICKUP, mc.player);

            tickDelay = 5;

            if (alertOnMove.get())
                mc.player.sendMessage(Text.literal("[AutoXP] Moved XP bottle to hotbar slot " + targetSlot + "."), false);
        }
    }

    private int findXPBottleSlot() {
        for (int i = 9; i < mc.player.getInventory().size(); i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.EXPERIENCE_BOTTLE) return i;
        }
        return -1;
    }

    private boolean isHotbarSlotEmpty(int slot) {
        return mc.player.getInventory().getStack(slot).isEmpty();
    }
}
