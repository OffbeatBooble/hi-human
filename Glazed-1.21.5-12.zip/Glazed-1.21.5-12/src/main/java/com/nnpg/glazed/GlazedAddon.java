package com.nnpg.glazed;

import com.nnpg.glazed.modules.*;
import com.nnpg.glazed.modules.esp.*;
import com.nnpg.glazed.modules.pvp.*;
import com.nnpg.glazed.modules.treefarmer.*;
import com.nnpg.glazed.modules.SafePackets;

import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.Category;

public class GlazedAddon extends MeteorAddon {
    public static final Category CATEGORY = new Category("glazed+");
    public static final Category esp = new Category("glazed+ ESPs");
    public static final Category pvp = new Category("glazed+ PVP");
    public static final Category treefarmer = new Category("glazed+ TreeFarmer");

    public static int VERSION = 12;

    @Override
    public void onInitialize() {
        // Register modules
        Modules.get().add(new SpawnerProtect());
        Modules.get().add(new PearlThrow());
        Modules.get().add(new RTPBaseFinder());
        Modules.get().add(new AntiTrap());
        Modules.get().add(new CoordSnapper());
        Modules.get().add(new AutoFirework());
        Modules.get().add(new ElytraSwap());
        Modules.get().add(new PlayerDetection());
        Modules.get().add(new AHSniper());
        Modules.get().add(new RTPer());
        Modules.get().add(new TunnelBaseFinder());
        Modules.get().add(new ShulkerDropper());
        Modules.get().add(new AutoSell());
        Modules.get().add(new SpawnerDropper());
        Modules.get().add(new AutoShulkerOrder());
        Modules.get().add(new AutoOrder());
        Modules.get().add(new HideScoreboard());
        Modules.get().add(new CrystalMacro());
        Modules.get().add(new AHSell());
        Modules.get().add(new AnchorMacro());
        Modules.get().add(new OneByOneHoles());
        Modules.get().add(new KelpESP());
        Modules.get().add(new DeepslateESP());
        Modules.get().add(new DripstoneESP());
        Modules.get().add(new RotatedDeepslateESP());
        Modules.get().add(new CrateBuyer());
        Modules.get().add(new WanderingESP());
        Modules.get().add(new VillagerESP());
        Modules.get().add(new AdvancedStashFinder());
        Modules.get().add(new TpaMacro());
        Modules.get().add(new TabDetector());
        Modules.get().add(new OrderSniper());
        Modules.get().add(new LamaESP());
        Modules.get().add(new PillagerESP());
        Modules.get().add(new HoleTunnelStairsESP());
        Modules.get().add(new CoveredHole());
        Modules.get().add(new ClusterFinder());
        Modules.get().add(new AutoShulkerShellOrder());
        Modules.get().add(new EmergencySeller());
        Modules.get().add(new AutoTreeFarmer());
        Modules.get().add(new RTPEndBaseFinder());
        Modules.get().add(new ShopBuyer());
        Modules.get().add(new OrderDropper());
        Modules.get().add(new ElytraAutoFly());
        Modules.get().add(new CollectibleESP());
        Modules.get().add(new SpawnerNotifier());
        Modules.get().add(new VineESP());
        Modules.get().add(new ChunkFinder());
        Modules.get().add(new BlockNotifier());
        Modules.get().add(new LegitAnchorMacro());
        Modules.get().add(new TreeFarmer());
        Modules.get().add(new AutoTreeFarmer2());
        Modules.get().add(new TpaAllMacro());
        Modules.get().add(new AutoTotem());
        Modules.get().add(new FastExp());
        Modules.get().add(new EnemyNametagRemover());
        Modules.get().add(new HoverTotem());
        Modules.get().add(new SafePackets()); // ✅ GUI module
        Modules.get().add(new NoBlockInteract());
        Modules.get().add(new HumanTriggerBot());
        Modules.get().add(new ReactiveShieldBreaker());
        Modules.get().add(new AutoXP());


    }


    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
        Modules.registerCategory(esp);
        Modules.registerCategory(pvp);
        Modules.registerCategory(treefarmer);
    }

    @Override
    public String getPackage() {
        return "com.nnpg.glazed";
    }
}
