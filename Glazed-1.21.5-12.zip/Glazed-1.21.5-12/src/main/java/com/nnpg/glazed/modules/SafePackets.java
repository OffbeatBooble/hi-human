package com.nnpg.glazed.modules;

import com.nnpg.glazed.GlazedAddon;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Vec3d;

public class SafePackets extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> fixMove = sgGeneral.add(new BoolSetting.Builder()
        .name("fix-move")
        .description("Fixes invalid move packets instead of blocking them.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> fixInteractBlock = sgGeneral.add(new BoolSetting.Builder()
        .name("fix-interact-block")
        .description("Fixes invalid block interaction packets instead of blocking them.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> fixSlot = sgGeneral.add(new BoolSetting.Builder()
        .name("fix-slot")
        .description("Fixes invalid slot packets instead of blocking them.")
        .defaultValue(true)
        .build()
    );

    public SafePackets() {
        super(GlazedAddon.CATEGORY, "safe-packets", "Sanitizes suspicious packets instead of blocking them.");
    }

    @EventHandler
    private void onSend(PacketEvent.Send event) {
        if (mc.player == null || mc.getNetworkHandler() == null) return;

        Packet<?> p = event.packet;

        // --- MOVE PACKETS ---
        if (p instanceof PlayerMoveC2SPacket packet && fixMove.get()) {
            double x = packet.getX(mc.player.getX());
            double y = packet.getY(mc.player.getY());
            double z = packet.getZ(mc.player.getZ());

            // Clamp Y within world bounds
            int topY = mc.world.getTopSectionCoord() * 16;
            if (y > topY) y = topY;
            if (y < mc.world.getBottomY()) y = mc.world.getBottomY();

            if (y != packet.getY(mc.player.getY())) {
                event.cancel();
                mc.getNetworkHandler().sendPacket(
                    new PlayerMoveC2SPacket.Full(
                        x, y, z,
                        packet.getYaw(mc.player.getYaw()),
                        packet.getPitch(mc.player.getPitch()),
                        packet.isOnGround(),
                        true // changingPositionAndRotation
                    )
                );
                info("Corrected suspicious move packet.");
            }
        }

        // --- INTERACT BLOCK PACKETS ---
        else if (p instanceof PlayerInteractBlockC2SPacket packet && fixInteractBlock.get()) {
            double distance = mc.player.getEyePos().distanceTo(packet.getBlockHitResult().getPos());

            if (distance > 6) {
                BlockHitResult old = packet.getBlockHitResult();
                BlockHitResult fixedHit = new BlockHitResult(
                    mc.player.getPos(),      // new hit position
                    old.getSide(),           // same facing
                    mc.player.getBlockPos(), // nearest block
                    false                    // no isInside() in 1.21.5
                );

                event.cancel();
                mc.getNetworkHandler().sendPacket(
                    new PlayerInteractBlockC2SPacket(packet.getHand(), fixedHit, packet.getSequence())
                );
                info("Corrected suspicious interact-block packet (reach).");
            }
        }

        // --- SLOT CHANGE PACKETS ---
        else if (p instanceof UpdateSelectedSlotC2SPacket packet && fixSlot.get()) {
            int slot = packet.getSelectedSlot();

            if (slot < 0 || slot > 8) {
                int fixedSlot = Math.min(Math.max(slot, 0), 8);
                event.cancel();
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(fixedSlot));
                info("Corrected suspicious slot packet (" + slot + " -> " + fixedSlot + ")");
            }
        }
    }
}



