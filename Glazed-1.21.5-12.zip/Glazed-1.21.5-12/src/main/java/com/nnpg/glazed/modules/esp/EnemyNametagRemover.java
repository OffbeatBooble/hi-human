package com.nnpg.glazed.modules.esp;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.AbstractClientPlayerEntity;

import static meteordevelopment.meteorclient.MeteorClient.mc;

import java.util.HashSet;
import java.util.Set;

public class EnemyNametagRemover extends Module {
    private static final Set<String> ENEMIES = new HashSet<>();

    public EnemyNametagRemover() {
        super(Categories.Render, "enemy-nametag-remover", "Removes nametags for enemies.");
    }

    public static void addEnemy(String name) {
        ENEMIES.add(name);
    }

    public static void removeEnemy(String name) {
        ENEMIES.remove(name);
    }

    private boolean isEnemy(String name) {
        return ENEMIES.contains(name);
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.world == null) return;

        for (AbstractClientPlayerEntity player : mc.world.getPlayers()) {
            String name = player.getName().getString();
            if (isEnemy(name)) {
                // Skip rendering by drawing nothing at the nametag position
                // Optionally: could draw a box here instead
            }
        }
    }
}
