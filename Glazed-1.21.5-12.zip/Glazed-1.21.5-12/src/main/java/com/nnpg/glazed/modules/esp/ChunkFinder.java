package com.nnpg.glazed.modules.esp;

import com.nnpg.glazed.GlazedAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import meteordevelopment.meteorclient.utils.render.color.Color;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ChunkFinder extends Module {
    private final Set<ChunkPos> suspiciousChunks = ConcurrentHashMap.newKeySet();
    private boolean isScanning = false;

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> minClusterSize = sgGeneral.add(new IntSetting.Builder()
        .name("minimum-cluster-size")
        .description("Minimum size of Andesite/Granite/Diorite cluster to consider intact.")
        .defaultValue(20)
        .min(1)
        .sliderRange(5, 50)
        .build()
    );

    private final Setting<Integer> maxY = sgGeneral.add(new IntSetting.Builder()
        .name("max-y")
        .description("Maximum Y-level to scan for clusters.")
        .defaultValue(64)
        .min(1)
        .max(255)
        .sliderRange(16, 128)
        .build()
    );

    private static final Block[] CLUSTER_BLOCKS = {Blocks.ANDESITE, Blocks.GRANITE, Blocks.DIORITE};

    public ChunkFinder() {
        super(GlazedAddon.esp, "chunk-finder", "Highlights mined Andesite/Granite/Diorite clusters with notifications.");
    }

    @Override
    public void onActivate() {
        if (mc.world == null || mc.player == null) return;
        suspiciousChunks.clear();
        isScanning = true;
    }

    @Override
    public void onDeactivate() {
        isScanning = false;
        suspiciousChunks.clear();
    }

    @EventHandler
    private void onChunkLoad(ChunkDataEvent event) {
        if (!isScanning) return;
        scanChunkSafe(event.chunk());
    }

    private boolean isClusterBlock(Block block) {
        for (Block b : CLUSTER_BLOCKS) if (block == b) return true;
        return false;
    }

    private int floodFillClusterSafe(Chunk chunk, BlockPos start, Set<BlockPos> visited, int maxBlocks) {
        Queue<BlockPos> queue = new LinkedList<>();
        queue.add(start);
        visited.add(start);
        int count = 0;

        while (!queue.isEmpty() && count < maxBlocks) {
            BlockPos current = queue.poll();
            count++;

            for (BlockPos offset : new BlockPos[]{
                current.north(), current.south(), current.east(), current.west(),
                current.up(), current.down()
            }) {
                if (!visited.contains(offset)) {
                    try {
                        if (isClusterBlock(chunk.getBlockState(offset).getBlock())) {
                            visited.add(offset);
                            queue.add(offset);
                        }
                    } catch (Exception ignored) {
                        // ignore unloaded blocks or exceptions
                    }
                }
            }
        }
        return count;
    }

    private void scanChunkSafe(Chunk chunk) {
        if (chunk == null || !isScanning) return;
        if (mc.player == null) return;

        ChunkPos chunkPos = chunk.getPos();
        Set<BlockPos> visited = new HashSet<>();
        boolean hasLargeCluster = false;
        boolean onlySmallClusters = true;

        for (int x = chunkPos.getStartX(); x < chunkPos.getStartX() + 16; x++) {
            for (int z = chunkPos.getStartZ(); z < chunkPos.getStartZ() + 16; z++) {
                for (int y = 0; y < maxY.get(); y++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!visited.contains(pos) && isClusterBlock(chunk.getBlockState(pos).getBlock())) {
                        int clusterSize = floodFillClusterSafe(chunk, pos, visited, 500); // limit 500 blocks to avoid crash
                        if (clusterSize >= minClusterSize.get()) {
                            hasLargeCluster = true;
                            onlySmallClusters = false;
                        }
                    }
                }
            }
        }

        if (!hasLargeCluster && onlySmallClusters) {
            if (!suspiciousChunks.contains(chunkPos)) {
                suspiciousChunks.add(chunkPos);
                mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F));
                if (mc.player != null) {
                    mc.player.sendMessage(
                        Text.literal("§aMined cluster detected at " + chunkPos.x + ", " + chunkPos.z),
                        false
                    );
                }
            }
        } else {
            suspiciousChunks.remove(chunkPos);
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.player == null) return;

        ShapeMode mode = ShapeMode.Both;
        Color boxColor = new Color(0, 255, 0, 100);

        // Only render chunks near the player to improve performance
        int renderRange = 5; // chunks
        int playerChunkX = mc.player.getChunkPos().x;
        int playerChunkZ = mc.player.getChunkPos().z;

        for (ChunkPos chunkPos : suspiciousChunks) {
            if (Math.abs(chunkPos.x - playerChunkX) > renderRange || Math.abs(chunkPos.z - playerChunkZ) > renderRange)
                continue;

            double inset = 0.2;
            double xStart = chunkPos.getStartX() + inset;
            double zStart = chunkPos.getStartZ() + inset;
            double xEnd = chunkPos.getEndX() + 1 - inset;
            double zEnd = chunkPos.getEndZ() + 1 - inset;

            double yStart = maxY.get() - 1;
            double yEnd = maxY.get();

            Box box = new Box(xStart, yStart, zStart, xEnd, yEnd, zEnd);
            event.renderer.box(box, boxColor, boxColor, mode, 1);
        }
    }
}


