package com.nnpg.glazed.modules.pvp;

import com.nnpg.glazed.GlazedAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> delay = sgGeneral.add(new DoubleSetting.Builder()
        .name("delay")
        .description("Delay in ticks before swapping totem")
        .defaultValue(1.0)
        .min(0.0).max(5.0)
        .sliderMax(5.0)
        .build()
    );

    private int delayCounter = 0;

    public AutoTotem() {
        super(GlazedAddon.pvp, "auto-totem", "Automatically holds a totem in your offhand.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        if (mc.player.getInventory().getStack(40).getItem() == Items.TOTEM_OF_UNDYING) {
            delayCounter = delay.get().intValue();
            return;
        }

        if (delayCounter > 0) {
            delayCounter--;
            return;
        }

        int slot = findItemSlot(Items.TOTEM_OF_UNDYING);
        if (slot == -1) return;

        mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, convertSlotIndex(slot), 40, SlotActionType.SWAP, mc.player);
        delayCounter = delay.get().intValue();
    }

    private int findItemSlot(Item item) {
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    private int convertSlotIndex(int slotIndex) {
        return slotIndex < 9 ? 36 + slotIndex : slotIndex;
    }
}
