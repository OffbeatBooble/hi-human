package com.nnpg.glazed.modules;

import com.nnpg.glazed.GlazedAddon;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.meteorclient.events.world.TickEvent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

public class HumanTriggerBot extends Module {

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final Random random = new Random();
    private long lastAttackTime = 0;

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> critChance = sgGeneral.add(new DoubleSetting.Builder()
        .name("crit-chance")
        .description("Chance to perform a jump attack (critical hit).")
        .defaultValue(0) // Default 0
        .min(0)
        .max(100)
        .sliderMin(0)
        .sliderMax(100)
        .build()
    );

    private final Setting<Double> attackDelay = sgGeneral.add(new DoubleSetting.Builder()
        .name("attack-delay-ms")
        .description("Randomized delay between attacks for human-like behavior.")
        .defaultValue(50)
        .min(0)
        .max(200)
        .sliderMin(0)
        .sliderMax(200)
        .build()
    );

    public HumanTriggerBot() {
        super(GlazedAddon.pvp, "human-trigger-bot", "Human-like 1.9 trigger bot with cooldown, crits, and swords/axes only.");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.world == null) return;

        // Only trigger if holding sword or axe
        ItemStack handItem = mc.player.getMainHandStack();
        if (!isSwordOrAxe(handItem)) return;

        Entity target = getEntityLookedAt(4.5);
        if (target instanceof PlayerEntity || target instanceof LivingEntity) {
            // Respect 1.9 attack cooldown
            float cooldown = mc.player.getAttackCooldownProgress(0.0F);
            if (cooldown < 1.0F) return;

            // Human-like randomized delay
            long now = System.currentTimeMillis();
            if (now - lastAttackTime < attackDelay.get() + random.nextInt(10)) return;

            // Determine if we should crit
            boolean doCrit = random.nextDouble() <= critChance.get() / 100.0;

            attack(target, doCrit);

            lastAttackTime = now;
        }
    }

    private boolean isSwordOrAxe(ItemStack stack) {
        return stack.isOf(Items.WOODEN_SWORD) || stack.isOf(Items.STONE_SWORD) ||
            stack.isOf(Items.IRON_SWORD) || stack.isOf(Items.GOLDEN_SWORD) ||
            stack.isOf(Items.DIAMOND_SWORD) || stack.isOf(Items.NETHERITE_SWORD) ||
            stack.isOf(Items.WOODEN_AXE) || stack.isOf(Items.STONE_AXE) ||
            stack.isOf(Items.IRON_AXE) || stack.isOf(Items.GOLDEN_AXE) ||
            stack.isOf(Items.DIAMOND_AXE) || stack.isOf(Items.NETHERITE_AXE);
    }

    private Entity getEntityLookedAt(double reach) {
        Vec3d eyePos = mc.player.getCameraPosVec(1.0f);
        Vec3d lookVec = mc.player.getRotationVec(1.0f);
        Vec3d endVec = eyePos.add(lookVec.multiply(reach));

        Entity closestEntity = null;
        double minDistance = reach;

        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof LivingEntity) || entity == mc.player) continue;

            Box box = entity.getBoundingBox().expand(0.3);
            if (box.raycast(eyePos, endVec).isPresent()) {
                double distance = mc.player.squaredDistanceTo(entity);
                if (distance < minDistance) {
                    minDistance = distance;
                    closestEntity = entity;
                }
            }
        }

        return closestEntity;
    }

    private void attack(Entity entity, boolean doCrit) {
        // Perform jump crit using space bar if critChance > 0
        if (doCrit && mc.player.isOnGround()) {
            mc.options.jumpKey.setPressed(true); // press space
        } else {
            mc.options.jumpKey.setPressed(false); // release
        }

        // Perform real left-click attack
        mc.interactionManager.attackEntity(mc.player, entity);
        mc.player.swingHand(mc.player.getActiveHand());
    }
}

