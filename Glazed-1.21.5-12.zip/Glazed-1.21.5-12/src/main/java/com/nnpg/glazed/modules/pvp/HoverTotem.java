package com.nnpg.glazed.modules.pvp;

import com.nnpg.glazed.GlazedAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

public class HoverTotem extends Module {
    //–– Settings ––//
    private final SettingGroup sgSteps = settings.createGroup("Steps");
    private final Setting<Boolean> holdFromHotbar = sgSteps.add(new BoolSetting.Builder()
        .name("hold-from-hotbar")
        .description("If enabled, switches your held hotbar slot to the first totem found.")
        .defaultValue(true)
        .build()
    );
    private final Setting<Boolean> openInventory = sgSteps.add(new BoolSetting.Builder()
        .name("open-inventory")
        .description("If enabled, opens your inventory before detecting hover.")
        .defaultValue(true)
        .build()
    );
    private final Setting<Boolean> waitForHover = sgSteps.add(new BoolSetting.Builder()
        .name("hover-to-trigger")
        .description("If enabled, waits for you to hover over a totem slot.")
        .defaultValue(true)
        .build()
    );
    private final Setting<Boolean> closeInventory = sgSteps.add(new BoolSetting.Builder()
        .name("close-inventory")
        .description("If enabled, closes your inventory after swapping if a totem was placed.")
        .defaultValue(true)
        .build()
    );

    //–– Delay Settings ––//
    private final SettingGroup sgDelays = settings.createGroup("Delay Settings");
    private final Setting<Integer> stageDelayMs = sgDelays.add(new IntSetting.Builder()
        .name("stage-delay-ms")
        .description("Minimum delay between each internal stage.")
        .defaultValue(100)
        .min(0).max(5000).sliderMax(5000)
        .build()
    );
    private final Setting<Integer> hoverTimeoutMs = sgDelays.add(new IntSetting.Builder()
        .name("hover-timeout-ms")
        .description("Max time to wait for you to hover before cancelling.")
        .defaultValue(2500)
        .min(0).max(10000).sliderMax(10000)
        .build()
    );

    //–– Constants & State ––//
    private static final int INV_BG_W     = 176;
    private static final int INV_BG_H     = 166;
    private static final int OFFHAND_SLOT = 45;

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private boolean wasHoldingTotem = true;
    private int stage               = -1;
    private long lastStageAt        = 0;
    private long hoverStartAt       = 0;
    private int hoveredSlotId       = -1;

    public HoverTotem() {
        super(GlazedAddon.pvp, "HoverTotem",
            "Pop → [hold hotbar] → [open inv] → [hover] → move to offhand → [close inv]."
        );
    }

    @Override
    public void onActivate() { reset(); }

    @Override
    public void onDeactivate() { reset(); }

    private void reset() {
        stage           = -1;
        lastStageAt     = 0;
        hoverStartAt    = 0;
        hoveredSlotId   = -1;
        wasHoldingTotem = mc.player != null
            && mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.interactionManager == null) return;

        boolean holdingNow = mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);

        // Detect Totem pop
        if (wasHoldingTotem && !holdingNow) {
            stage           = 0;
            lastStageAt     = 0;
            hoverStartAt    = 0;
            hoveredSlotId   = -1;
        }
        wasHoldingTotem = holdingNow;
        if (stage < 0) return;

        long now = System.currentTimeMillis();
        if (now - lastStageAt < stageDelayMs.get()) return;

        switch (stage) {
            // Stage 0: switch your held hotbar slot to the totem
            case 0 -> {
                if (holdFromHotbar.get()) {
                    int hotbarSlot = findHotbarTotem();
                    if (hotbarSlot != -1) {
                        PlayerInventory inv = mc.player.getInventory();
                        inv.setSelectedSlot(hotbarSlot);
                        mc.player.networkHandler.sendPacket(
                            new UpdateSelectedSlotC2SPacket(hotbarSlot)
                        );
                    }
                }
                advance(now);
            }

            // Stage 1: open the inventory screen
            case 1 -> {
                if (openInventory.get()) {
                    mc.setScreen(new InventoryScreen(mc.player));
                }
                advance(now);
            }

            // Stage 2: wait for hover (or auto-find)
            case 2 -> {
                if (!isInventoryReady()) return;

                if (waitForHover.get()) {
                    if (hoverStartAt == 0) hoverStartAt = now;

                    Slot hovered = getHoveredSlot();
                    if (isTotemSlot(hovered)) {
                        hoveredSlotId = hovered.id;
                        advance(now); // → Stage 3
                    }
                    else if (hoverTimeoutMs.get() > 0 && now - hoverStartAt > hoverTimeoutMs.get()) {
                        // Timeout expired with no hover → cancel sequence
                        reset();
                    }
                    // else: keep waiting until hover
                }
                else {
                    Slot any = findAnyTotemSlot();
                    hoveredSlotId = (any != null ? any.id : -1);
                    advance(now); // → Stage 3
                }
            }

            // Stage 3: click into offhand
            case 3 -> {
                if (!isInventoryReady()) return;
                if (hoveredSlotId >= 0) {
                    int syncId = mc.player.currentScreenHandler.syncId;
                    mc.interactionManager.clickSlot(syncId, hoveredSlotId, 0, SlotActionType.PICKUP, mc.player);
                    mc.interactionManager.clickSlot(syncId, OFFHAND_SLOT,   0, SlotActionType.PICKUP, mc.player);
                }
                advance(now);
            }

            // Stage 4: close inventory only if we actually have a totem
            case 4 -> {
                if (closeInventory.get() && mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                    mc.setScreen(null);
                }
                reset();
            }
        }
    }

    private void advance(long now) {
        lastStageAt = now;
        stage++;
    }

    private int findHotbarTotem() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                return i;
            }
        }
        return -1;
    }

    private boolean isInventoryReady() {
        return mc.currentScreen instanceof InventoryScreen
            && mc.player.currentScreenHandler != null
            && !mc.player.currentScreenHandler.slots.isEmpty();
    }

    private Slot getHoveredSlot() {
        if (!(mc.currentScreen instanceof InventoryScreen inv)) return null;

        double mx = mc.mouse.getX() * mc.getWindow().getScaledWidth()  / mc.getWindow().getWidth();
        double my = mc.mouse.getY() * mc.getWindow().getScaledHeight() / mc.getWindow().getHeight();
        int guiLeft = (inv.width  - INV_BG_W) / 2;
        int guiTop  = (inv.height - INV_BG_H) / 2;

        for (Slot s : inv.getScreenHandler().slots) {
            int sx = guiLeft + s.x, sy = guiTop + s.y;
            if (mx >= sx && mx < sx + 16 && my >= sy && my < sy + 16) {
                return s;
            }
        }
        return null;
    }

    private boolean isTotemSlot(Slot slot) {
        return slot != null
            && slot.hasStack()
            && slot.getStack().isOf(Items.TOTEM_OF_UNDYING);
    }

    private Slot findAnyTotemSlot() {
        if (!(mc.currentScreen instanceof InventoryScreen inv)) return null;

        for (Slot s : inv.getScreenHandler().slots) {
            if (isTotemSlot(s)) {
                return s;
            }
        }
        return null;
    }
}
